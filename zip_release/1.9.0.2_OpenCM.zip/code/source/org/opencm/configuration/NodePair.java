package org.opencm.configuration;

public class NodePair {

    private Node node01;
    private Node node02;
    public NodePair() {
    }

    public Node getNode_01() {
        return this.node01;
    }
    public void setNode_01(Node node01) {
        this.node01 = node01;
    }
    public Node getNode_02() {
        return this.node02;
    }
    public void setNode_02(Node node02) {
        this.node02 = node02;
    }
}
