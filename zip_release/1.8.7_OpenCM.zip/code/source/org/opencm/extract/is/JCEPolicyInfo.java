package org.opencm.extract.is;

public class JCEPolicyInfo {

	private String key;
	private String value;

	public JCEPolicyInfo() {
	}
	
	public String getKey() {
		return this.key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	
	public String getValue() {
		return this.value;
	}
	public void setValue(String val) {
		this.value = val;
	}

}
