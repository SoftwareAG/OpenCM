package OpenCM.pub;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.InputStream;
import java.io.IOException;
// --- <<IS-END-IMPORTS>> ---

public final class tesdfgsfd

{
	// ---( internal utility methods )---

	final static tesdfgsfd _instance = new tesdfgsfd();

	static tesdfgsfd _newInstance() { return new tesdfgsfd(); }

	static tesdfgsfd _cast(Object o) { return (tesdfgsfd)o; }

	// ---( server methods )---




	public static final void test (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(test)>> ---
		// @sigtype java 3.5
		System.out.println(" ----------------------------------------------- ");
		 
		/**
		import org.linguafranca.pwdb.Credentials;
		import org.linguafranca.pwdb.Entry;
		import org.linguafranca.pwdb.Group;
		import org.linguafranca.pwdb.Icon;
		import org.linguafranca.pwdb.Visitor;
		import org.linguafranca.pwdb.Database;
		import org.linguafranca.pwdb.kdbx.KdbxCreds;
		import org.linguafranca.pwdb.kdbx.simple.SimpleDatabase;
		try {
			 // Open Database
			String db = "C:\\SoftwareAG\\keepass\\OpenCM.kdbx";
			String pwd = "manage";
		    KdbxCreds creds = new KdbxCreds(pwd.getBytes());
			InputStream inputStream = Class.class.getClassLoader().getResourceAsStream(db);
			Database database = SimpleDatabase.load(creds, inputStream);
		    database.visit(new Visitor.Print());
		} catch (Exception ex) {
			System.out.println("Exception: " + ex.getMessage());
		}
		
		*/
				
			
		// --- <<IS-END>> ---

                
	}
}

