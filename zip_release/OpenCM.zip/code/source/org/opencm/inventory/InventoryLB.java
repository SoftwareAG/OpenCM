package org.opencm.inventory;

public class InventoryLB {

    private String url;
    private String port;

    public InventoryLB() {
    }
    
    public String getUrl() {
        return this.url;
    }
    public void setUrl(String url) {
        this.url = url;
    }
    public String getPort() {
        return this.port;
    }
    public void setPort(String port) {
        this.port = port;
    }
    
}
