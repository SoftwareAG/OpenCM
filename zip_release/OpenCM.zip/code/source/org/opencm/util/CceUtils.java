package org.opencm.util;

public class CceUtils {
		
	public static String CCE_TEMPLATE_FILENAME 	= "cce.json"; 
		

}